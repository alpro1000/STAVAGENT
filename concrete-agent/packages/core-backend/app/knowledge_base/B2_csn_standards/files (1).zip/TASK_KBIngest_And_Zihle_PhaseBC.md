# TASK: KB Ingest (UPa+EN1992-2+lifecycle) + Žihle Phase B+C

**Priorita:** P2 (sandbox experiment, ne pro odevzdání tendru)
**Trvání odhad:** 3-5 hodin Claude Code
**Návaznost:**
- Předchozí task: Žihle Phase A (extraction) — DONE, branch `claude/setup-bridge-test-project-X41DO`, commit `cd0f2a19`
- Tento task: KB ingest + Phase B (návrh) + Phase C (calculator) → final summary

---

## Мантра

> Сначала ты читаешь весь репо.
> Не делаешь предположений о naming, путях, структуре — аудитуешь existing
> conventions ВСЕГДА. Surgical approach: minimum changes, maximum reuse.
>
> KB enrichment делаем по Knowledge Placement Guide (`docs/normy/...` или
> аналогичный, найди сам). Файлы которые я подготовил — минимальные;
> Claude Code их положит в правильные buckets per existing conventions.
>
> Если данные блокируют решение и не могут быть отрезолвлены из контекста
> репо — STOP и AskUserQuestion. Лучше пауза чем wrong assumption.

---

## ČÁST 1: KB INGEST

User v repo do `concrete-agent/packages/core-backend/app/knowledge_base/B2_csn_standards/`
už nahrál 2 PDF:
- `09_zatizitelnost__sanace.pdf` (UPa lecture slides)
- `SIST-EN-1992-2-2005.pdf` (Eurocode 2 — Concrete bridges)

Podle `KNOWLEDGE_PLACEMENT_GUIDE.md` v repo (najdi přesný path) by měly být:
- UPa slides → `B6_research_papers/` (univerzitní skriptum, ne norma)
- EN 1992-2 → `B7_regulations/` (nebo `B2_csn_standards/` pokud je to existing convention)
- ČSN 73 6222 stub → `B7_regulations/` (placená norma, jen stand-in přes UPa)
- Lifecycle data → `B9_validation/`

**Audit decision:** Mně připraveny soubory mají v sobě referenční slug names.
Podle KNOWLEDGE_PLACEMENT_GUIDE rozhodni sám:
- Jestli přesouvat PDF na správný bucket nebo nechat v B2 a jen vytvořit metadata
- Přesné názvy podsložek (slug)
- Format INDEX (existující buckets používají JSON nebo YAML — zachovaj convention)

### 1.1 Vytvořit 4 KB entries

User dodá 4 sady souborů (drag&drop ze chat outputs):

| # | Slug (návrh) | Files | Bucket |
|---|---|---|---|
| 1 | `upa_zatizitelnost_sanace_mostu` | METADATA.md + INDEX.yaml + citations.md | B6_research_papers/ |
| 2 | `csn_73_6222_zatizitelnost_mostu` | METADATA.md + INDEX.yaml | B7_regulations/ (stub — paid norm) |
| 3 | `en_1992_2_concrete_bridges` | METADATA.md + INDEX.yaml | B7_regulations/ (PARTIAL extraction) |
| 4 | `lifecycle_durability` | lifecycle_table.yaml | B9_validation/ |

### 1.2 Pravidla pro umístění

**Neporušuj existující strukturu B2_csn_standards.** Pokud audit ukáže že:
- B2_csn_standards je legitimní legacy bucket pro ČSN-like (včetně Eurocode), nech tam PDF, ale extracted YAML/MD dej do B7_regulations s pointer na PDF v B2.
- B6_research_papers existuje a funguje pro skripta, použij ho pro UPa slides.
- Žádný pattern pro INDEX (.yaml vs .json) v repo — analogie sleduj `tkp/` podpapku v B2 (která existuje 3 měsíce) pro precedent.

### 1.3 Aktualizovat existující soubory

- Pokud existuje `metadata.json` v `B2_csn_standards/` → přidat reference na 2 nové PDFs
- Pokud existuje `KNOWLEDGE_PLACEMENT_GUIDE.md` → poznámka v sekci "Příklady reálných zdrojů" že UPa skriptum patří do B6, EN 1992-2 do B7
- **Žádné** zásahy do TKP folder (legacy, nedotýkaj)

### 1.4 Acceptance criteria — Část 1

1. ✅ 4 nové KB entries existují s METADATA + INDEX
2. ✅ PDFs jsou buď v B2_csn_standards (legacy) nebo přesunuté + pointer
3. ✅ Žádné porušení existujících struktur
4. ✅ INDEX.yaml soubory jsou validní YAML (loadable by `yaml.safe_load`)
5. ✅ Cross-references mezi entries fungují (relativní paths)

---

## ČÁST 2: ŽIHLE PHASE B — NÁVRH

**Cíl:** Vytvořit první návrh nové NK pro Žihle 2062-1 s plnou justifikací z KB.

**Vstupy:**
- Phase A artefakty: `test-data/most-2062-1-zihle/01_extraction/` (4 YAML files)
- Nové KB entries (z Části 1)
- Existující KB: `B6_research_papers/upa_pokorny_suchanek_betonove_mosty_ii/`
- Existing calculator: `Monolit-Planner/shared/`

### 2.1 Klíčová zjištění z Phase A (carry forward)

| Fact | Hodnota | Zdroj | Confidence |
|---|---|---|---|
| Stávající rozpětí | ~9 m | Mostní list BMS | 0.7 (rukopis) |
| Šikmost | 50° | HPM + mostní list | 0.9 |
| Stávající trámy | 16× ŽB s I-280 | HPM s.2 | 0.85 |
| Stav NK | VI havarijní | HPM | 1.0 |
| Stav SS | IV uspokojivý | HPM | 1.0 |
| Svetlá výška pod mostem | ~1 m | foto | 0.5 |
| ZD vyžaduje Vn=32 / Vr=80 / Ve=180 t | skupina 1 | ZD §4.4.h | 1.0 |
| ZD: bez ložisek, bez dilatací, bez složitého odvodnění | čl. 4.4.l | ZD | 1.0 |
| Provizorium povinné (objízdná zamítnuta) | čl. 4.4.o + Vysvětlení | ZD | 1.0 |

### 2.2 Co vytvořit v `02_design/`

Konvence názvů sleduj per existing repo (žádný established pattern → jednoduché kebab-case).

**a) `varianta_01_integralni_ram.md`** — Hlavní návrh (markdown narrative)

Obsah:
- **Statický systém:** rámový integrální most, jedno pole, deska + opěry tvoří jeden celek.
  - Justifikace: ZD §4.4.l zakazuje ložiska + dilatace → integrální rám je technicky jediná akceptabilní varianta. Pokorný-Suchánek kap. 4 (rámové mosty pro malé pólová s rozpětím do ~30 m, monolitické, staticky neurčité).
- **Hlavní rozměry:**
  - Světlá rozpětí: 9.0 m (s rezervou pro hydrologii — finalna hodnota dle geodézie)
  - Tloušťka desky: 0.45 m
    - Justifikace: Pokorný-Suchánek tab. 15 (rámový most, L=9m → 1/20–1/30 L = 0.30–0.45 m; pro Vn=32t volíme horní hranici)
  - Šířka mostu: ~8.30 m (vozovka 6.50 m + 2× římsa 0.90 m)
    - Justifikace: ZD čl. 4.4.c kategorie S 7,5 (vozovka mezi V4)
  - Skosení: 50° (per HPM stávajícího mostu, finální hodnota dle geodézie zhotovitele)
- **Spodní stavba:**
  - Plošný základ na únosné základové spáře (předpoklad — IGP zhotovitele)
  - Dříky opěr: 0.50 m (integrální spojení s deskou)
  - Závěrné zídky: 0.35 × 0.80 m
  - **Bez křídel** — svahový kužel 1:1.5
- **Přechodové desky:** 4.0 × 8.30 × 0.30 m (per ČSN 73 6244)
- **Materiály:**
  - Beton C30/37 (per EN 1992-2 §3.1.2 doporučení a Annex E pro XC4)
  - Krytí: viz tabulka v `concrete_classes.yaml`
- **Technologie výstavby:**
  - Sequenчní (skruž zdola **nemožná** — světlá výška 1 m):
    1. Provizorium boční (foto 132429 — místo vpravo)
    2. Demolice stávajícího mostu
    3. Stavební jáma na úroveň založení nové stavby
    4. Plošný základ + opěry betonáž
    5. Pevná skruž ze stojek IP / DOKA Multiprop / PERI Multiprop **z dna stavební jámy**
    6. Bednění + výztuž + betonáž desky
    7. Třída ošetřování 4 dle TKP18 §7.8.3 (≥ 9 dní při 15-25°C)
    8. Odbednění po dosažení 70% pevnosti
    9. Závěrné zídky, přechodové desky
    10. Mostní svršek (izolace, vozovka, římsy, svodidla)
    11. Demontáž provizoria + úprava koryta + opevnění

**b) `decomposition_so.md`** — SO breakdown analogově Kfely (s adaptacemi):

| SO | Název | Status pro Žihle |
|---|---|---|
| SO 001 | Demolice stávajícího mostu | ✅ stejné jako Kfely |
| SO 180 | **Provizorium** (NE objízdná!) | ⚠️ kritická diference vs Kfely |
| SO 201 | Most ev.č. 2062-1 (nová stavba) | ✅ analogicky Kfely SO 201 |
| ZS | Zařízení staveniště | ✅ |

**c) `concrete_classes.yaml`** — Strukturovaná tabulka per element s justifikací:

```yaml
# Příklad formátu (rozhodni sám per repo conventions)
elements:
  podkladni_beton:
    concrete_class: C12/15
    exposure: X0
    justification: "EN 1992-2 Annex E + standard practice for non-structural blinder"
    cover_mm: null  # není konstrukční
  
  zaklad_oper:
    concrete_class: C25/30
    exposure: "XC2 + XF1"
    justification: "Pod terénem, vlhké prostředí. EN 1992-2 §4.4 + Annex E"
    cover_mm: 50
  
  drik_oper:
    concrete_class: C30/37
    exposure: "XC4 + XF2"
    justification: "Zóna stříkající vody. Annex E doporučuje C30/37 pro XF2."
    cover_mm: 50
  
  mostovka_deska:
    concrete_class: C30/37
    exposure: "XC4 + XF2"
    justification: "Spodní líc nad potokem (XF2 zóna). Annex E + EN 1992-2 §3.1.2 doporučený C_min."
    cover_mm: 40
  
  rimsy:
    concrete_class: C30/37
    exposure: "XC4 + XF2 + XD1"
    justification: "Direct contact s posypovou solí možný (zima). XD1 přidán per praxe."
    cover_mm: 50
  
  prechodove_desky:
    concrete_class: C25/30
    exposure: "XC2 + XF1"
    justification: "Pod izolací + vozovkou, méně agresivní. ČSN 73 6244 + EN 1992-2 Annex E."
    cover_mm: 35
```

**d) `formwork_choice.md`** — Výběr bednění + skruže:

- **Vertikální bednění** (opěry, závěrné zídky):
  - DOKA Framax Xlife nebo PERI Trio (rámové bednění)
  - Tlak čerstvého betonu dle DIN 18218 — pro výšku ~2 m a stupeň konzistence S3 → ~50 kN/m² (standardní rámové)
- **Horizontální bednění** (deska):
  - DOKA Top 50 nebo PERI Multiflex (nosníkový systém)
- **Skruž / podpora desky**:
  - Stojky IP (české inventární), DOKA Multiprop, nebo PERI Multiprop
  - **Z dna stavební jámy** (nikoli z přirozeného terénu — světlá výška 1m nestačí)
  - Per Pokorný-Suchánek kap. 14: pevná skruž stojkami pro mosty s výškou NK 10-15 m (náš ~3 m vyhovuje)
  - **Pevná skruž**, NE posuvná (jen 1 pole)

**e) `provizorium_specs.md`** — Spec provizoria (orientačně, bez RFQ):

- Typ: Mabey Compact 200 / Bailey panel / Acrow 700 series — **rozhodnout dle vzoru** zhotovitele
- Délka: ~12 m (přemostění + nájezdy)
- Únosnost: 3.5 t (per ZD §4.4.o) + linková doprava
- Provoz: jednosměrný se světelnou signalizací
- Trvání: ~4-6 měsíců (demolice 1-2 měs + výstavba 3-4 měs)
- Náklady: **flag "to-verify with vendor RFQ"** — orientačně 1.5-2.5 mil. Kč (montáž+nájem 6 měs + demontáž)

**f) `element_breakdown.yaml`** — Vstup pro kalkulátor:

Strukturovaný seznam elementů s parametry pro calculator (geometrie, beton, exposure, výztuž ratio, technologie). Toto bude vstup do Phase C.

### 2.3 Pravidla pro Phase B

🔴 **Každé rozhodnutí MUSÍ mít citaci zdroje.** Pokud neexistuje zdroj v KB:
- Flag jako "engineering judgment" + rationale
- Pokud je rozhodnutí kritické a chybí source → STOP a AskUserQuestion

🔴 **Použij existující classifier** (`element-classifier.ts` v `Monolit-Planner/shared/`) — neimplementuj nový. Audituj jak Žihle elementy mappují na existující element_types.

🔴 **Použij KB priorities** dle `KNOWLEDGE_PLACEMENT_GUIDE.md`:
1. ČSN EN (EN 1992-2 — máme)
2. TKP ŘSD (TKP 18 — pokud existuje v repo)
3. ČSN národní (73 6222 — máme stub)
4. Univerzitní (Pokorný-Suchánek, UPa lecture)
5. Ostatní

### 2.4 Acceptance criteria — Část 2

6. ✅ `02_design/` obsahuje všech 6 deliverables (a-f)
7. ✅ Každé rozhodnutí v `varianta_01.md` má citaci zdroje
8. ✅ `concrete_classes.yaml` per element s exposure + krytí + justifikace
9. ✅ `element_breakdown.yaml` connects ke calculator inputs
10. ✅ `provizorium_specs.md` má explicit "to-verify" flag pro náklady

---

## ČÁST 3: ŽIHLE PHASE C — CALCULATION

### 3.1 Mechanizmus volání kalkulátoru

**Per user decision (potvrzeno v chatu):** Node CLI script v `03_calculation/`,
import z `Monolit-Planner/shared/dist`.

### 3.2 Co vytvořit

**a) `03_calculation/run-calc.ts`** (nebo `.js` pokud TS není v sandboxu setuped)

Pseudocode:
```typescript
import { runCalculator /* nebo equivalentní */ } from '../../../Monolit-Planner/shared/dist';
import * as fs from 'fs';
import * as path from 'path';
import * as yaml from 'js-yaml';

const inputs = yaml.load(fs.readFileSync('../02_design/element_breakdown.yaml'));
const outputs = {};

for (const [elementId, elementInput] of Object.entries(inputs.elements)) {
  outputs[elementId] = await runCalculator(elementInput);
}

fs.writeFileSync('outputs/calculator_outputs.json', JSON.stringify(outputs, null, 2));
```

> **Audit nejdříve:** existing tests (např. `golden-vp4-forestina.test.ts`)
> používají jaký import? Sleduj stejný pattern.

**b) `03_calculation/inputs.json`** — auto-generated z `02_design/element_breakdown.yaml`

**c) `03_calculation/outputs/`** — per-element PlannerOutput JSONs

**d) `03_calculation/cost_summary.xlsx`** — agregát:
- Sheet 1: Per-element summary (element / volume / formwork area / labour h / cost)
- Sheet 2: Per SO summary (SO 001 / SO 180 / SO 201 / ZS)
- Sheet 3: Total bez DPH + headroom proti 30 mil. Kč
- Sheet 4: Harmonogram (per-element duration days)

Použij `openpyxl` (Python) nebo `exceljs` (Node) — sleduj existing convention.

**e) `03_calculation/gantt_chart.svg`** nebo `.png` — vizuální harmonogram

**f) `03_calculation/README.md`** — instrukce jak spustit:
```bash
cd Monolit-Planner/shared && pnpm build  # one-time
cd test-data/most-2062-1-zihle/03_calculation
pnpm tsx run-calc.ts
```

### 3.3 Připočítat mimo kalkulátor

- **SO 001 Demolice:** orientační odhad z Kfely SO 001 + scaling factor 1:17 (Kfely 815 m² vs Žihle ~46 m² mostovky), flag jako approximation
- **SO 180 Provizorium:** orientační vendor estimate z `provizorium_specs.md`, flag "to-verify"
- **ZS:** 3-5% z hlavních prací (per ČSN 73 0212)

### 3.4 Acceptance criteria — Část 3

11. ✅ `run-calc.ts` reálně spustitelný (ne pseudocode), reálně volá calculator
12. ✅ Calculator outputs preserved jako JSON (audit trail)
13. ✅ `cost_summary.xlsx` má 4 sheets (per-element / per-SO / total / harmonogram)
14. ✅ Total porovnáno proti 30 mil. Kč (explicit "fits/exceeds by X")
15. ✅ Provizorium má separate line item s confidence flag

---

## ČÁST 4: SUMMARY

### 4.1 Vytvořit `00_PROJECT_SUMMARY.md`

Obsah:
- **Bottom line** (1-2 věty): vejde se / nevejde do 30 mil. Kč? Realistická doba?
- **3 největší rizika** D&B nabídky
- **Missing data** (geodézie, IGP, hydrologie, mostní list — co BMS dodá)
- **Recommendations:** jít/nejít do tendru a pod jakými podmínkami

### 4.2 Update `metadata.yaml`

- `status: calculated` (z předchozího `extraction_done`)
- Přidat sekci `phase_b_design_decisions` se shrnutím
- Přidat sekci `phase_c_calculation_results` s headline numbery

### 4.3 Update `README.md`

- Odkazy na všechny vytvořené artefakty
- Workflow status: A ✅ B ✅ C ✅ → ready for golden test conversion

### 4.4 Acceptance criteria — Část 4

16. ✅ `00_PROJECT_SUMMARY.md` obsahuje executive findings + rizika
17. ✅ `metadata.yaml` status = `calculated`
18. ✅ `README.md` updated

---

## CROSS-CUTTING ACCEPTANCE CRITERIA

19. ✅ **Žádný kód mimo `test-data/most-2062-1-zihle/` a KB enrichment** nebyl změněn
    (calculator core, classifier, existing KB extracted YAMLs — vše jen čteme)
20. ✅ KB enrichment respektuje existing buckets (B2/B6/B7/B9 per guide)
21. ✅ Existing CI tests projdou (žádný regression)
22. ✅ Všechny artefakty jsou textové a/nebo XLSX — žádné binární cache

---

## ČO NEPATRÍ DO TOHTO TASKU

- ❌ Plná extraction EN 1992-2 (PARTIAL only — Žihle-relevantní sections)
- ❌ Změny v calculator core / classifier / existing KB
- ❌ Nové KB buckets (B10+)
- ❌ Generace finálního TZ pro DUR/DSP (next task — `04_documentation/`)
- ❌ KROS XC4 export soupisu prací (next task)
- ❌ Vytvoření golden test pod `test-data/tz/bridges/` (až po dokončení 04)
- ❌ Real RFQ na provizorium vendor
- ❌ Geodézie / IGP / hydrologie (mimo scope — flag jako missing)

---

## PRE-IMPLEMENTATION INTERVIEW (před kódem!)

1. **KB structure audit:** existuje `KNOWLEDGE_PLACEMENT_GUIDE.md` v repo?
   Jaké jsou existing buckets v `concrete-agent/packages/core-backend/app/knowledge_base/`?
   Jaký format INDEX (yaml/json)? — sleduj convention z `tkp/` v B2_csn_standards.

2. **PDFs already in B2:** PDF jsou v `B2_csn_standards/`. Mám je tam nechat
   (legacy bucket pattern) nebo přesunout do B7? Audit `metadata.json` v B2 —
   pokud má reference na PDFs, nech tam.

3. **Calculator import path:** kde je calculator entry point pro Node consumers?
   Audit `Monolit-Planner/shared/package.json` exports + jak ho používá
   `golden-*.test.ts`. Sleduj stejný pattern.

4. **Excel generator:** existuje shared utility pro XLSX export v repo?
   Pokud ne, napsat helper v `03_calculation/utils.ts` (NOT v shared/).

5. **YAML vs JSON:** repo používá oba. Pro nové KB entries — sleduj convention
   per bucket (B2 má JSON, B6 má YAML — pro B7 rozhodni).

6. **Phase A artefakty:** existují v `01_extraction/`? Branch
   `claude/setup-bridge-test-project-X41DO` — merged do main? Pokud ne, audit
   commit `cd0f2a19`.

> Pokud na cokoliv neumíš dát jednoznačnou odpověď z auditu — STOP a polož
> otázku přes AskUserQuestion. Лучше пауза чем wrong assumption.

---

## VÝSTUP DO CHATU PO DOKONČENÍ

Po dokončení всех 4 částí uveď v odpovědi:

1. **Bottom line:** vejde se Žihle do 30 mil. Kč? Doba? (1-2 věty)
2. **3 největší rizika** (bullety)
3. **Strom artefaktů:**
   ```
   tree -L 3 test-data/most-2062-1-zihle/
   tree -L 2 concrete-agent/packages/core-backend/app/knowledge_base/B6_research_papers/upa_*
   tree -L 2 concrete-agent/packages/core-backend/app/knowledge_base/B7_regulations/
   ```
4. **Status statistiky:** kolik KB entries vytvořeno, kolik rules dokumentováno
5. **Co je třeba pro skutečné podání nabídky** (nedělaný work list)

---

## Naming a strukturu určuj podle existujících konvencí v repu.
## Pokud existuje konflikt mezi UPa slides (vendor reference) a EN 1992-2
## (autoritative norm) — vždy vítězí EN 1992-2. UPa je teaching simplification.
